package com.csvproject;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class ReadAndWrite {
	public static void main(String[] args) throws IOException {
		ReadAndWrite object = new ReadAndWrite();
		List<String[]> data_file_output_added = new ArrayList<String[]>();
		List<String[]> data_file_output_removed = new ArrayList<String[]>();
		List<String[]> data_file_output_modified = new ArrayList<String[]>();

		List<String[]> file_one = object.readcsv("src/main/resources/file_one.csv");
		List<String[]> file_two = object.readcsv("src/main/resources/file_two.csv");
		for (String[] two : file_two) {
			for (String[] one : file_one) {
				if (Arrays.equals(two, one)) {
					data_file_output_modified.add(one);
					break;
				}

			}

		}


		for (String[] two : file_two) {
			int a = 0;
			for(String[] one : file_one) {
				if(Arrays.equals(two, one)){
					break;
				}
				a=a+1;
				}
			if(file_two.size()==a) {
				data_file_output_added.add(two);
			}
			
			}
		for (String[] one : file_one) {
			int a = 0;
			for(String[] two : file_two) {
				if(Arrays.equals(one, two)){
					break;
				}
				a=a+1;
				}
			if(file_two.size()==a) {
				data_file_output_removed.add(one);
			}
			
			}
		object.writecsv("src/main/createdCsv/file_output_added.csv", data_file_output_added);
		object.writecsv("src/main/createdCsv/file_output_removed.csv", data_file_output_removed);
		object.writecsv("src/main/createdCsv/file_output_modified.csv", data_file_output_modified);
	}

	public List<String[]> readcsv(String FilePath) throws IOException {
		// Build reader instance
		CSVReader file_one = new CSVReader(new FileReader(FilePath));

		// Read all rows at once
		List<String[]> All_Data = file_one.readAll();

		return All_Data;
	}

	public void writecsv(String fileName, List<String[]> data) throws IOException {
		CSVWriter writer = new CSVWriter(new FileWriter(fileName));

		// Create record
		writer.writeAll(data);

		// close the writer
		writer.close();
	}
}
